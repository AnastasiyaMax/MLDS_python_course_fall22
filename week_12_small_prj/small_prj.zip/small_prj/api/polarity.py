import pandas as pd
from textblob import TextBlob

df = pd.read_csv('api/data/Womens_Reviews.csv')

def get_polarity_all(df=df):
    df['Sentiment_Polarity'] = df['Review Text'].apply(lambda text:
                                                       TextBlob(text).sentiment.polarity)
    return df

def get_polarity_one(text):
    return TextBlob(text).sentiment.polarity
