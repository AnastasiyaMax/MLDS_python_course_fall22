
from fastapi import APIRouter

from api import polarity
from config.celery_utils import get_task_info
from schemas.schemas import Review

router = APIRouter(prefix='/polarities', tags=['Polarity'], responses={404: {"description": "Not found"}})

@router.post("/")
def get_polarities(review: Review) -> dict:
    return polarity.get_polarity_one(review.review)

@router.get("/task/{task_id}")
async def get_task_status(task_id: str) -> dict:
    return get_task_info(task_id)



