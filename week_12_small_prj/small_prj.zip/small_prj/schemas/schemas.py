from pydantic import BaseModel

class Review(BaseModel):
    review: str

    class Config:
        with open('schemas/sample_review.txt', 'r') as f:
            text = f.readline()

        schema_extra = {
            "example": {
                "review": text,
            }
        }
